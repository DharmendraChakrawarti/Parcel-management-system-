package dao;

import model.Booking;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookingDAO {
    
    public int createBooking(Booking booking) {
        String sql = """
            INSERT INTO bookings (customer_id, customer_name, customer_address, rec_name, rec_address, 
                                rec_pin, rec_mobile, par_weight_gram, par_contents_description, 
                                par_delivery_type, par_packing_preference, par_pickup_time, 
                                par_dropoff_time, par_service_cost, par_payment_time, par_status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """;
        
        try (Connection conn = DatabaseUtil.getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, booking.getCustomerId());
            stmt.setString(2, booking.getCustomerName());
            stmt.setString(3, booking.getCustomerAddress());
            stmt.setString(4, booking.getRecName());
            stmt.setString(5, booking.getRecAddress());
            stmt.setString(6, booking.getRecPin());
            stmt.setString(7, booking.getRecMobile());
            stmt.setDouble(8, booking.getParWeightGram());
            stmt.setString(9, booking.getParContentsDescription());
            stmt.setString(10, booking.getParDeliveryType());
            stmt.setString(11, booking.getParPackingPreference());
            stmt.setTimestamp(12, booking.getParPickupTime());
            stmt.setTimestamp(13, booking.getParDropoffTime());
            stmt.setDouble(14, booking.getParServiceCost());
            stmt.setTimestamp(15, booking.getParPaymentTime());
            stmt.setString(16, booking.getParStatus());
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }
    
    public Booking getBookingById(int bookingId) {
        String sql = "SELECT * FROM bookings WHERE booking_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, bookingId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return mapResultSetToBooking(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public List<Booking> getBookingsByCustomerId(int customerId) {
        String sql = "SELECT * FROM bookings WHERE customer_id = ? ORDER BY booking_date DESC";
        List<Booking> bookings = new ArrayList<>();
        
        try (Connection conn = DatabaseUtil.getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, customerId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                bookings.add(mapResultSetToBooking(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bookings;
    }
    
    public List<Booking> getAllBookings() {
        String sql = "SELECT * FROM bookings ORDER BY booking_date DESC";
        List<Booking> bookings = new ArrayList<>();
        
        try (Connection conn = DatabaseUtil.getConnection(); 
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                bookings.add(mapResultSetToBooking(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bookings;
    }
    
    public boolean updateBookingStatus(int bookingId, String status) {
        String sql = "UPDATE bookings SET par_status = ? WHERE booking_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, status);
            stmt.setInt(2, bookingId);
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean updatePickupDropoffTime(int bookingId, Timestamp pickupTime, Timestamp dropoffTime) {
        String sql = "UPDATE bookings SET par_pickup_time = ?, par_dropoff_time = ? WHERE booking_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setTimestamp(1, pickupTime);
            stmt.setTimestamp(2, dropoffTime);
            stmt.setInt(3, bookingId);
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    private Booking mapResultSetToBooking(ResultSet rs) throws SQLException {
        Booking booking = new Booking();
        booking.setBookingId(rs.getInt("booking_id"));
        booking.setCustomerId(rs.getInt("customer_id"));
        booking.setCustomerName(rs.getString("customer_name"));
        booking.setCustomerAddress(rs.getString("customer_address"));
        booking.setRecName(rs.getString("rec_name"));
        booking.setRecAddress(rs.getString("rec_address"));
        booking.setRecPin(rs.getString("rec_pin"));
        booking.setRecMobile(rs.getString("rec_mobile"));
        booking.setParWeightGram(rs.getDouble("par_weight_gram"));
        booking.setParContentsDescription(rs.getString("par_contents_description"));
        booking.setParDeliveryType(rs.getString("par_delivery_type"));
        booking.setParPackingPreference(rs.getString("par_packing_preference"));
        booking.setParPickupTime(rs.getTimestamp("par_pickup_time"));
        booking.setParDropoffTime(rs.getTimestamp("par_dropoff_time"));
        booking.setParServiceCost(rs.getDouble("par_service_cost"));
        booking.setParPaymentTime(rs.getTimestamp("par_payment_time"));
        booking.setParStatus(rs.getString("par_status"));
        booking.setBookingDate(rs.getTimestamp("booking_date"));
        return booking;
    }
}
