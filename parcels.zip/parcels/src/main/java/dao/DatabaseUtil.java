package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseUtil {
    private static final String DB_URL = "jdbc:derby:C:\\Users\\DC\\parcell;create=true";
    private static final String DB_DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";

    static {
        try {
            Class.forName(DB_DRIVER);
            createTables();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL);
    }

    private static void createTables() {
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            
            // Create Users table
            String createUsersTable = """
                CREATE TABLE users (
                    user_id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
                    user_name VARCHAR(50) NOT NULL,
                    email VARCHAR(100) NOT NULL UNIQUE,
                    mobile_number VARCHAR(15) NOT NULL,
                    address VARCHAR(500) NOT NULL,
                    user_login_id VARCHAR(20) NOT NULL UNIQUE,
                    password VARCHAR(30) NOT NULL,
                    role VARCHAR(10) NOT NULL,
                    preferences VARCHAR(500)
                )
            """;

            // Create Bookings table
            String createBookingsTable = """
                CREATE TABLE bookings (
                    booking_id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
                    customer_id INT NOT NULL,
                    customer_name VARCHAR(50) NOT NULL,
                    customer_address VARCHAR(500) NOT NULL,
                    rec_name VARCHAR(50) NOT NULL,
                    rec_address VARCHAR(500) NOT NULL,
                    rec_pin VARCHAR(10) NOT NULL,
                    rec_mobile VARCHAR(15) NOT NULL,
                    par_weight_gram DOUBLE NOT NULL,
                    par_contents_description VARCHAR(500) NOT NULL,
                    par_delivery_type VARCHAR(50) NOT NULL,
                    par_packing_preference VARCHAR(100) NOT NULL,
                    par_pickup_time TIMESTAMP,
                    par_dropoff_time TIMESTAMP,
                    par_service_cost DOUBLE NOT NULL,
                    par_payment_time TIMESTAMP NOT NULL,
                    par_status VARCHAR(20) NOT NULL DEFAULT 'Booked',
                    booking_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (customer_id) REFERENCES users(user_id)
                )
            """;

            try {
                stmt.executeUpdate(createUsersTable);
            } catch (SQLException e) {
                // Table might already exist
            }

            try {
                stmt.executeUpdate(createBookingsTable);
            } catch (SQLException e) {
                // Table might already exist
            }

            // Insert default officer account
            String insertOfficer = """
                INSERT INTO users (user_name, email, mobile_number, address, user_login_id, password, role, preferences)
                VALUES ('Admin Officer', 'admin@courier.com', '+911234567890', 'Main Office, City', 'admin', 'Admin@123', 'OFFICER', 'Email notifications enabled')
            """;
            
            try {
                stmt.executeUpdate(insertOfficer);
            } catch (SQLException e) {
                // Officer might already exist
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
