package dao;

import model.Role;
import model.User;
import java.sql.*;

public class UserDAO {
    
    public boolean registerUser(User user) {
        String sql = """
            INSERT INTO users (user_name, email, mobile_number, address, user_login_id, password, role, preferences)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """;
        
        try (Connection conn = DatabaseUtil.getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, user.getUserName());
            stmt.setString(2, user.getEmail());
            stmt.setString(3, user.getMobileNumber());
            stmt.setString(4, user.getAddress());
            stmt.setString(5, user.getUserLoginId());
            stmt.setString(6, user.getPassword());
            stmt.setString(7, user.getRole().name());
            stmt.setString(8, user.getPreferences());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public User loginUser(String userLoginId, String password) {
        String sql = "SELECT * FROM users WHERE user_login_id = ? AND password = ?";
        
        try (Connection conn = DatabaseUtil.getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, userLoginId);
            stmt.setString(2, password);
            
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                User user = new User();
                user.setUserId(rs.getInt("user_id"));
                user.setUserName(rs.getString("user_name"));
                user.setEmail(rs.getString("email"));
                user.setMobileNumber(rs.getString("mobile_number"));
                user.setAddress(rs.getString("address"));
                user.setUserLoginId(rs.getString("user_login_id"));
                user.setPassword(rs.getString("password"));
                user.setRole(Role.valueOf(rs.getString("role")));
                user.setPreferences(rs.getString("preferences"));
                return user;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public boolean isUserLoginIdExists(String userLoginId) {
        String sql = "SELECT COUNT(*) FROM users WHERE user_login_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, userLoginId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean isEmailExists(String email) {
        String sql = "SELECT COUNT(*) FROM users WHERE email = ?";
        
        try (Connection conn = DatabaseUtil.getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
