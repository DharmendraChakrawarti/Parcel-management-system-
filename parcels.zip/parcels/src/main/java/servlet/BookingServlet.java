package servlet;

import dao.BookingDAO;
import model.Booking;
import model.Role;
import model.User;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@WebServlet("/BookingServlet")
public class BookingServlet extends HttpServlet {
    private BookingDAO bookingDAO = new BookingDAO();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String recName = request.getParameter("recName");
        String recAddress = request.getParameter("recAddress");
        String recPin = request.getParameter("recPin");
        String recMobile = request.getParameter("recMobile");
        String parWeightGramStr = request.getParameter("parWeightGram");
        String parContentsDescription = request.getParameter("parContentsDescription");
        String parDeliveryType = request.getParameter("parDeliveryType");
        String parPackingPreference = request.getParameter("parPackingPreference");
        String parPickupTimeStr = request.getParameter("parPickupTime");
        String parDropoffTimeStr = request.getParameter("parDropoffTime");

        // For officer bookings, get sender details
        String senderName = request.getParameter("senderName");
        String senderAddress = request.getParameter("senderAddress");
        String senderMobile = request.getParameter("senderMobile");

        // Validation
        StringBuilder errors = new StringBuilder();
        
        if (recName == null || recName.trim().isEmpty()) {
            errors.append("Receiver name is required. ");
        }
        if (recAddress == null || recAddress.trim().isEmpty()) {
            errors.append("Receiver address is required. ");
        }
        if (recPin == null || recPin.trim().isEmpty()) {
            errors.append("Receiver PIN is required. ");
        }
        if (recMobile == null || recMobile.trim().isEmpty()) {
            errors.append("Receiver mobile is required. ");
        }
        if (parWeightGramStr == null || parWeightGramStr.trim().isEmpty()) {
            errors.append("Parcel weight is required. ");
        }
        if (parContentsDescription == null || parContentsDescription.trim().isEmpty()) {
            errors.append("Contents description is required. ");
        }
        if (parDeliveryType == null || parDeliveryType.trim().isEmpty()) {
            errors.append("Delivery type is required. ");
        }
        if (parPackingPreference == null || parPackingPreference.trim().isEmpty()) {
            errors.append("Packing preference is required. ");
        }

        if (user.getRole() == Role.OFFICER) {
            if (senderName == null || senderName.trim().isEmpty()) {
                errors.append("Sender name is required. ");
            }
            if (senderAddress == null || senderAddress.trim().isEmpty()) {
                errors.append("Sender address is required. ");
            }
            if (senderMobile == null || senderMobile.trim().isEmpty()) {
                errors.append("Sender mobile is required. ");
            }
        }

        if (errors.length() > 0) {
            request.setAttribute("error", errors.toString());
            request.getRequestDispatcher("booking.jsp").forward(request, response);
            return;
        }

        try {
            double parWeightGram = Double.parseDouble(parWeightGramStr);
            
            Booking booking = new Booking();
            booking.setCustomerId(user.getUserId());
            
            if (user.getRole() == Role.CUSTOMER) {
                booking.setCustomerName(user.getUserName());
                booking.setCustomerAddress(user.getAddress());
            } else {
                booking.setCustomerName(senderName);
                booking.setCustomerAddress(senderAddress);
            }
            
            booking.setRecName(recName);
            booking.setRecAddress(recAddress);
            booking.setRecPin(recPin);
            booking.setRecMobile(recMobile);
            booking.setParWeightGram(parWeightGram);
            booking.setParContentsDescription(parContentsDescription);
            booking.setParDeliveryType(parDeliveryType);
            booking.setParPackingPreference(parPackingPreference);

            // Parse pickup and dropoff times
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
            if (parPickupTimeStr != null && !parPickupTimeStr.trim().isEmpty()) {
                booking.setParPickupTime(new Timestamp(sdf.parse(parPickupTimeStr).getTime()));
            }
            if (parDropoffTimeStr != null && !parDropoffTimeStr.trim().isEmpty()) {
                booking.setParDropoffTime(new Timestamp(sdf.parse(parDropoffTimeStr).getTime()));
            }

            // Calculate service cost based on weight and delivery type
            double serviceCost = calculateServiceCost(parWeightGram, parDeliveryType);
            booking.setParServiceCost(serviceCost);

            int bookingId = bookingDAO.createBooking(booking);
            if (bookingId > 0) {
                request.setAttribute("success", "Booking created successfully! Booking ID: " + bookingId);
                request.setAttribute("bookingId", bookingId);
                request.getRequestDispatcher("invoice.jsp").forward(request, response);
            } else {
                request.setAttribute("error", "Booking creation failed. Please try again.");
                request.getRequestDispatcher("booking.jsp").forward(request, response);
            }

        } catch (NumberFormatException e) {
            request.setAttribute("error", "Invalid weight format.");
            request.getRequestDispatcher("booking.jsp").forward(request, response);
        } catch (ParseException e) {
            request.setAttribute("error", "Invalid date/time format.");
            request.getRequestDispatcher("booking.jsp").forward(request, response);
        }
    }

    private double calculateServiceCost(double weightGram, String deliveryType) {
        double baseCost = 50.0; // Base cost
        double weightCost = (weightGram / 100) * 10; // 10 rupees per 100g
        
        double multiplier = switch (deliveryType.toLowerCase()) {
            case "express" -> 2.0;
            case "overnight" -> 1.5;
            default -> 1.0; // standard
        };
        
        return (baseCost + weightCost) * multiplier;
    }
}
