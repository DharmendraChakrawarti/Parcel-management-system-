package servlet;

import dao.UserDAO;
import model.Role;
import model.User;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.regex.Pattern;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private UserDAO userDAO = new UserDAO();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String userName = request.getParameter("userName");
        String email = request.getParameter("email");
        String countryCode = request.getParameter("countryCode");
        String mobileNumber = request.getParameter("mobileNumber");
        String address = request.getParameter("address");
        String userLoginId = request.getParameter("userLoginId");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        String preferences = request.getParameter("preferences");

        // Validation
        StringBuilder errors = new StringBuilder();

        if (userName == null || userName.trim().isEmpty() || userName.length() > 50) {
            errors.append("Customer name is required and must be less than 50 characters. ");
        }

        if (email == null || !isValidEmail(email)) {
            errors.append("Valid email is required. ");
        }

        if (mobileNumber == null || mobileNumber.length() != 10 || !mobileNumber.matches("\\d{10}")) {
            errors.append("10-digit mobile number is required. ");
        }

        if (address == null || address.trim().isEmpty()) {
            errors.append("Address is required. ");
        }

        if (userLoginId == null || userLoginId.length() < 5 || userLoginId.length() > 20) {
            errors.append("User ID must be between 5 and 20 characters. ");
        }

        if (password == null || password.length() > 30 || !isValidPassword(password)) {
            errors.append("Password must be max 30 characters with at least one uppercase, lowercase, and special character. ");
        }

        if (!password.equals(confirmPassword)) {
            errors.append("Passwords do not match. ");
        }

        // Check if user ID or email already exists
        if (userDAO.isUserLoginIdExists(userLoginId)) {
            errors.append("User ID already exists. ");
        }

        if (userDAO.isEmailExists(email)) {
            errors.append("Email already exists. ");
        }

        if (errors.length() > 0) {
            request.setAttribute("error", errors.toString());
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        // Create user
        User user = new User();
        user.setUserName(userName);
        user.setEmail(email);
        user.setMobileNumber(countryCode + mobileNumber);
        user.setAddress(address);
        user.setUserLoginId(userLoginId);
        user.setPassword(password);
        user.setRole(Role.CUSTOMER);
        user.setPreferences(preferences);

        if (userDAO.registerUser(user)) {
            request.setAttribute("success", "Registration successful! Please login.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        } else {
            request.setAttribute("error", "Registration failed. Please try again.");
            request.getRequestDispatcher("register.jsp").forward(request, response);
        }
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pat = Pattern.compile(emailRegex);
        return pat.matcher(email).matches();
    }

    private boolean isValidPassword(String password) {
        return password.matches(".*[A-Z].*") && 
               password.matches(".*[a-z].*") && 
               password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*");
    }
}
