package servlet;

import dao.BookingDAO;
import model.Booking;
import model.Role;
import model.User;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/HistoryServlet")
public class HistoryServlet extends HttpServlet {
    private BookingDAO bookingDAO = new BookingDAO();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        List<Booking> bookings;
        if (user.getRole() == Role.CUSTOMER) {
            bookings = bookingDAO.getBookingsByCustomerId(user.getUserId());
        } else {
            bookings = bookingDAO.getAllBookings();
        }

        request.setAttribute("bookings", bookings);
        request.getRequestDispatcher("history.jsp").forward(request, response);
    }
}
