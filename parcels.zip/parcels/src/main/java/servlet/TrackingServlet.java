package servlet;

import dao.BookingDAO;
import model.Booking;
import model.Role;
import model.User;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/TrackingServlet")
public class TrackingServlet extends HttpServlet {
    private BookingDAO bookingDAO = new BookingDAO();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String bookingIdStr = request.getParameter("bookingId");
        
        if (bookingIdStr != null && !bookingIdStr.trim().isEmpty()) {
            try {
                int bookingId = Integer.parseInt(bookingIdStr);
                
                if (user.getRole() == Role.CUSTOMER) {
                    // For customers, show only their bookings
                    List<Booking> customerBookings = bookingDAO.getBookingsByCustomerId(user.getUserId());
                    Booking booking = customerBookings.stream()
                            .filter(b -> b.getBookingId() == bookingId)
                            .findFirst()
                            .orElse(null);
                    
                    if (booking != null) {
                        request.setAttribute("booking", booking);
                    } else {
                        request.setAttribute("error", "Booking not found or not authorized to view.");
                    }
                } else {
                    // For officers, show any booking
                    Booking booking = bookingDAO.getBookingById(bookingId);
                    if (booking != null) {
                        request.setAttribute("booking", booking);
                    } else {
                        request.setAttribute("error", "Booking not found.");
                    }
                }
            } catch (NumberFormatException e) {
                request.setAttribute("error", "Invalid booking ID format.");
            }
        }

        request.getRequestDispatcher("tracking.jsp").forward(request, response);
    }
}
