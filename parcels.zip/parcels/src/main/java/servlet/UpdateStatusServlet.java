package servlet;

import dao.BookingDAO;
import model.Booking;
import model.Role;
import model.User;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@WebServlet("/UpdateStatusServlet")
public class UpdateStatusServlet extends HttpServlet {
    private BookingDAO bookingDAO = new BookingDAO();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || user.getRole() != Role.OFFICER) {
            response.sendRedirect("login.jsp");
            return;
        }

        String bookingIdStr = request.getParameter("bookingId");
        if (bookingIdStr != null && !bookingIdStr.trim().isEmpty()) {
            try {
                int bookingId = Integer.parseInt(bookingIdStr);
                Booking booking = bookingDAO.getBookingById(bookingId);
                if (booking != null) {
                    request.setAttribute("booking", booking);
                } else {
                    request.setAttribute("error", "Booking not found.");
                }
            } catch (NumberFormatException e) {
                request.setAttribute("error", "Invalid booking ID format.");
            }
        }

        request.getRequestDispatcher("update-status.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || user.getRole() != Role.OFFICER) {
            response.sendRedirect("login.jsp");
            return;
        }

        String action = request.getParameter("action");
        String bookingIdStr = request.getParameter("bookingId");

        if (bookingIdStr == null || bookingIdStr.trim().isEmpty()) {
            request.setAttribute("error", "Booking ID is required.");
            request.getRequestDispatcher("update-status.jsp").forward(request, response);
            return;
        }

        try {
            int bookingId = Integer.parseInt(bookingIdStr);

            if ("updateStatus".equals(action)) {
                String newStatus = request.getParameter("newStatus");
                if (newStatus != null && !newStatus.trim().isEmpty()) {
                    if (bookingDAO.updateBookingStatus(bookingId, newStatus)) {
                        request.setAttribute("success", "Status updated successfully!");
                    } else {
                        request.setAttribute("error", "Failed to update status.");
                    }
                }
            } else if ("updatePickupDropoff".equals(action)) {
                String pickupTimeStr = request.getParameter("pickupTime");
                String dropoffTimeStr = request.getParameter("dropoffTime");

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
                Timestamp pickupTime = null;
                Timestamp dropoffTime = null;

                if (pickupTimeStr != null && !pickupTimeStr.trim().isEmpty()) {
                    pickupTime = new Timestamp(sdf.parse(pickupTimeStr).getTime());
                }
                if (dropoffTimeStr != null && !dropoffTimeStr.trim().isEmpty()) {
                    dropoffTime = new Timestamp(sdf.parse(dropoffTimeStr).getTime());
                }

                if (bookingDAO.updatePickupDropoffTime(bookingId, pickupTime, dropoffTime)) {
                    request.setAttribute("success", "Pickup/Dropoff times updated successfully!");
                } else {
                    request.setAttribute("error", "Failed to update pickup/dropoff times.");
                }
            }

            // Refresh booking data
            Booking booking = bookingDAO.getBookingById(bookingId);
            request.setAttribute("booking", booking);

        } catch (NumberFormatException e) {
            request.setAttribute("error", "Invalid booking ID format.");
        } catch (ParseException e) {
            request.setAttribute("error", "Invalid date/time format.");
        }

        request.getRequestDispatcher("update-status.jsp").forward(request, response);
    }
}
