package model;

import java.sql.Timestamp;

public class Booking {
    private int bookingId;
    private int customerId;
    private String customerName;
    private String customerAddress;
    private String recName;
    private String recAddress;
    private String recPin;
    private String recMobile;
    private double parWeightGram;
    private String parContentsDescription;
    private String parDeliveryType;
    private String parPackingPreference;
    private Timestamp parPickupTime;
    private Timestamp parDropoffTime;
    private double parServiceCost;
    private Timestamp parPaymentTime;
    private String parStatus;
    private Timestamp bookingDate;

    // Constructors
    public Booking() {
        this.parStatus = "Booked";
        this.bookingDate = new Timestamp(System.currentTimeMillis());
        this.parPaymentTime = new Timestamp(System.currentTimeMillis());
    }

    // Getters and Setters
    public int getBookingId() { return bookingId; }
    public void setBookingId(int bookingId) { this.bookingId = bookingId; }

    public int getCustomerId() { return customerId; }
    public void setCustomerId(int customerId) { this.customerId = customerId; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getCustomerAddress() { return customerAddress; }
    public void setCustomerAddress(String customerAddress) { this.customerAddress = customerAddress; }

    public String getRecName() { return recName; }
    public void setRecName(String recName) { this.recName = recName; }

    public String getRecAddress() { return recAddress; }
    public void setRecAddress(String recAddress) { this.recAddress = recAddress; }

    public String getRecPin() { return recPin; }
    public void setRecPin(String recPin) { this.recPin = recPin; }

    public String getRecMobile() { return recMobile; }
    public void setRecMobile(String recMobile) { this.recMobile = recMobile; }

    public double getParWeightGram() { return parWeightGram; }
    public void setParWeightGram(double parWeightGram) { this.parWeightGram = parWeightGram; }

    public String getParContentsDescription() { return parContentsDescription; }
    public void setParContentsDescription(String parContentsDescription) { this.parContentsDescription = parContentsDescription; }

    public String getParDeliveryType() { return parDeliveryType; }
    public void setParDeliveryType(String parDeliveryType) { this.parDeliveryType = parDeliveryType; }

    public String getParPackingPreference() { return parPackingPreference; }
    public void setParPackingPreference(String parPackingPreference) { this.parPackingPreference = parPackingPreference; }

    public Timestamp getParPickupTime() { return parPickupTime; }
    public void setParPickupTime(Timestamp parPickupTime) { this.parPickupTime = parPickupTime; }

    public Timestamp getParDropoffTime() { return parDropoffTime; }
    public void setParDropoffTime(Timestamp parDropoffTime) { this.parDropoffTime = parDropoffTime; }

    public double getParServiceCost() { return parServiceCost; }
    public void setParServiceCost(double parServiceCost) { this.parServiceCost = parServiceCost; }

    public Timestamp getParPaymentTime() { return parPaymentTime; }
    public void setParPaymentTime(Timestamp parPaymentTime) { this.parPaymentTime = parPaymentTime; }

    public String getParStatus() { return parStatus; }
    public void setParStatus(String parStatus) { this.parStatus = parStatus; }

    public Timestamp getBookingDate() { return bookingDate; }
    public void setBookingDate(Timestamp bookingDate) { this.bookingDate = bookingDate; }
}
