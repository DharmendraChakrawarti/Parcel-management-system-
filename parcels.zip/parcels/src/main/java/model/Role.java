package model;

public enum Role {
    CUSTOMER, OFFICER
}
